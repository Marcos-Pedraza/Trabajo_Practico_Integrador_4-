import entidades.*;
import entidades.DTOs.FacturaReporteDTO;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("FacturacionPU");
        EntityManager em = emf.createEntityManager();

        try {
            em.getTransaction().begin();

            // 1. Usuario (Hereda de EntityId)
            Usuario usuario = new Usuario();
            usuario.setUsuario("admin");
            usuario.setClave("1234");
            usuario.setNombre("Juan");
            usuario.setApellido("Perez");
            em.persist(usuario);

            // 2. Punto de Venta (Hereda de EntityId)
            PuntoVenta puntoVenta = new PuntoVenta();
            puntoVenta.setNumero(1);
            puntoVenta.setDescripcion("Punto Central 01");
            em.persist(puntoVenta);

            // 3. Crear Rubro y Marca (Para Articulo)
            Rubro rubro = new Rubro();
            rubro.setCodigo(10);
            rubro.setDenominacion("Perifericos");
            rubro.setFechaCreacion(new Date());
            rubro.setUsuarioCreacion("admin");
            em.persist(rubro);

            Marca marca = new Marca();
            marca.setCodigo(20);
            marca.setDenominacion("Logitech");
            marca.setFechaCreacion(new Date());
            marca.setUsuarioCreacion("admin");
            em.persist(marca);

            // 4. Crear Articulo
            Articulo articulo = new Articulo();
            articulo.setCodigo("A001");
            articulo.setDenominacion("Teclado Mecanico");
            articulo.setPrecioVenta(15000.0);
            articulo.setRubro(rubro);
            articulo.setMarca(marca);
            articulo.setFechaCreacion(new Date());
            articulo.setUsuarioCreacion("admin");
            em.persist(articulo);

            // 5. Instanciar CondicionIva, TipoMoneda y Cliente
            CondicionIva condIva = new CondicionIva();
            condIva.setCodigoAfip(1);
            condIva.setDenominacion("Responsable Inscripto");
            condIva.setFechaCreacion(new Date());
            condIva.setUsuarioCreacion("admin");
            em.persist(condIva);

            TipoMoneda moneda = new TipoMoneda();
            moneda.setCodigoAfip("ARS");
            moneda.setDenominacion("Pesos Argentinos");
            moneda.setSimbolo("$");
            moneda.setFechaCreacion(new Date());
            moneda.setUsuarioCreacion("admin");
            em.persist(moneda);

            Domicilio domicilio = new Domicilio();
            domicilio.setNombreCalle("San Martin");
            domicilio.setNumeroCalle("123");

            Cliente cliente = new Cliente();
            cliente.setCuit("20-12345678-9");
            cliente.setDenominacion("Empresa Test S.A.");
            cliente.setEmail("cliente@test.com");
            cliente.setCondicionIva(condIva);
            cliente.setDomicilio(domicilio); // Persiste en cascada
            cliente.setFechaCreacion(new Date());
            cliente.setUsuarioCreacion("admin");
            em.persist(cliente);

            // 6. Crear FacturaVenta (Cabecera)
            FacturaVenta facturaVenta = new FacturaVenta();
            facturaVenta.setNumero(1001L);
            facturaVenta.setFechaEmision(new Date());
            facturaVenta.setPuntoVenta(puntoVenta);
            facturaVenta.setCliente(cliente);
            facturaVenta.setCondicionIva(condIva);
            facturaVenta.setTipoMoneda(moneda);
            facturaVenta.setImporteTotal(30000.0);
            facturaVenta.setImporteCobrado(30000.0);
            facturaVenta.setImporteSaldo(0.0);
            facturaVenta.setEstado("EMITIDA");
            facturaVenta.setFechaCreacion(new Date());
            facturaVenta.setUsuarioCreacion("admin");
            facturaVenta.setDetalles(new ArrayList<>());

            // 7. Crear el Detalle
            FacturaVentaDetalle detalle1 = new FacturaVentaDetalle();
            detalle1.setCantidad(2);
            detalle1.setPrecioUnitario(15000.0);
            detalle1.setSubtotal(30000.0);
            detalle1.setArticulo(articulo);
            detalle1.setFactura(facturaVenta);

            facturaVenta.getDetalles().add(detalle1);

            // 8. Persistir en cascada
            em.persist(facturaVenta);

            em.getTransaction().commit();
            System.out.println("¡Datos insertados con exito!");

            // -------------------------------------------------------------
            // PARTE 2: Consulta JPQL con Proyeccion por Constructor (DTO)
            // -------------------------------------------------------------
            System.out.println("\n--- EJECUTANDO REPORTE DTO CON JPQL ---");

            String jpql = "SELECT new entidades.DTOs.FacturaReporteDTO(" +
                    "f.id, " +
                    "f.numero, " +
                    "f.fechaEmision, " +
                    "c.denominacion, " +
                    "c.cuit, " +
                    "f.importeTotal, " +
                    "f.estado, " +
                    "COUNT(d.id)) " +
                    "FROM FacturaVenta f " +
                    "LEFT JOIN f.cliente c " +
                    "LEFT JOIN f.detalles d " +
                    "GROUP BY f.id, f.numero, f.fechaEmision, c.denominacion, c.cuit, f.importeTotal, f.estado";

            TypedQuery<FacturaReporteDTO> query = em.createQuery(jpql, FacturaReporteDTO.class);
            List<FacturaReporteDTO> resultados = query.getResultList();

            for (FacturaReporteDTO item : resultados) {
                System.out.println(item);
            }

            // Obtener y mostrar la ruta absoluta donde se crearán
            String rutaActual = new java.io.File(".").getAbsolutePath();
            System.out.println("Los archivos se estan guardando en: " + rutaActual);

            // Generar Excel
            entidades.reportes.GeneradorExcel.exportarExcel(resultados, "reporte_facturas.xls");
            System.out.println("Archivo Excel generado con éxito: reporte_facturas.xls");

            // Generar PDF
            entidades.reportes.GeneradorPDF.exportarPDF(resultados, "reporte_facturas.pdf");
            System.out.println("Archivo PDF generado con éxito: reporte_facturas.pdf");

        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }
}