package entidades;

import jakarta.persistence.*;
import lombok.*;


@Entity
@Table(name = "domicilios")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(callSuper = true)
@ToString
public class Domicilio extends EntityId {
    private String nombreCalle;
    private String numeroCalle;

}

