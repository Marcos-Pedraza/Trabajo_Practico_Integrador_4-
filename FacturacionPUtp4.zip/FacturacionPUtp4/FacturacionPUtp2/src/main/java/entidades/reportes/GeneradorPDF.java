package entidades.reportes;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import entidades.DTOs.FacturaReporteDTO;

import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

public class GeneradorPDF {

    public static void exportarPDF(List<FacturaReporteDTO> lista, String rutaArchivo) throws DocumentException, IOException {
        Document document = new Document(PageSize.A4.rotate()); // Horizontal para que entren todas las columnas
        PdfWriter.getInstance(document, new FileOutputStream(rutaArchivo));
        document.open();

        // Título del reporte
        Font fontTitulo = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD);
        Paragraph titulo = new Paragraph("Reporte Ejecutivo de Facturas", fontTitulo);
        titulo.setAlignment(Element.ALIGN_CENTER);
        titulo.setSpacingAfter(20);
        document.add(titulo);

        // Tabla con 8 columnas
        PdfPTable table = new PdfPTable(8);
        table.setWidthPercentage(100);

        String[] headers = {"ID", "N° Factura", "Fecha", "Cliente", "CUIT", "Total", "Estado", "Items"};
        Font fontHeader = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD);

        for (String header : headers) {
            PdfPCell cell = new PdfPCell(new Phrase(header, fontHeader));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
            cell.setPadding(5);
            table.addCell(cell);
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Font fontData = new Font(Font.FontFamily.HELVETICA, 9, Font.NORMAL);

        for (FacturaReporteDTO f : lista) {
            table.addCell(new Phrase(f.getId() != null ? f.getId().toString() : "", fontData));
            table.addCell(new Phrase(f.getNumeroFactura() != null ? f.getNumeroFactura().toString() : "", fontData));
            table.addCell(new Phrase(f.getFechaEmision() != null ? sdf.format(f.getFechaEmision()) : "", fontData));
            table.addCell(new Phrase(f.getRazonSocialCliente() != null ? f.getRazonSocialCliente() : "", fontData));
            table.addCell(new Phrase(f.getCuitCliente() != null ? f.getCuitCliente() : "", fontData));
            table.addCell(new Phrase(f.getTotalFactura() != null ? String.format("%.2f", f.getTotalFactura()) : "", fontData));
            table.addCell(new Phrase(f.getEstado() != null ? f.getEstado() : "", fontData));
            table.addCell(new Phrase(f.getCantidadItems() != null ? f.getCantidadItems().toString() : "", fontData));
        }

        document.add(table);
        document.close();
    }
}
