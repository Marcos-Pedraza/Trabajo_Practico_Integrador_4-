package entidades.reportes;

import entidades.DTOs.FacturaReporteDTO;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

public class GeneradorExcel {

    public static void exportarExcel(List<FacturaReporteDTO> lista, String rutaArchivo) throws IOException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaArchivo))) {
            // Cabecera separada por tabulaciones
            writer.write("ID\tN° Factura\tFecha\tCliente\tCUIT\tTotal\tEstado\tItems");
            writer.newLine();

            // Filas de datos
            for (FacturaReporteDTO f : lista) {
                writer.write(String.format("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s",
                        f.getId() != null ? f.getId() : "",
                        f.getNumeroFactura() != null ? f.getNumeroFactura() : "",
                        f.getFechaEmision() != null ? sdf.format(f.getFechaEmision()) : "",
                        f.getRazonSocialCliente() != null ? f.getRazonSocialCliente() : "",
                        f.getCuitCliente() != null ? f.getCuitCliente() : "",
                        f.getTotalFactura() != null ? f.getTotalFactura() : 0.0,
                        f.getEstado() != null ? f.getEstado() : "",
                        f.getCantidadItems() != null ? f.getCantidadItems() : 0
                ));
                writer.newLine();
            }
        }
    }
}
