package entidades;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = {"entidades.controladores", "entidades.servicios", "entidades.repositorios", "entidades"})
@EnableJpaRepositories(basePackages = "entidades.repositorios")
@EntityScan(basePackages = "entidades")
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}


