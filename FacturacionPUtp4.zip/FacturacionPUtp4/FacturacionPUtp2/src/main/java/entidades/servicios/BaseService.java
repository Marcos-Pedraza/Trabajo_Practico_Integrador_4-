package entidades.servicios;

import entidades.EntityId;
import java.io.Serializable;
import java.util.List;
import java.util.Optional;

public interface BaseService<E extends EntityId, ID extends Serializable> {
    List<E> listarTodos();
    Optional<E> buscarPorId(ID id);
    E guardar(E entidad);
    void eliminar(ID id);
}
