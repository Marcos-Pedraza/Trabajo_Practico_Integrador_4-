package entidades.servicios;

import entidades.EntityId;
import entidades.repositorios.BaseRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

public abstract class BaseServiceImpl<E extends EntityId, ID extends Serializable> implements BaseService<E, ID> {

    @Autowired
    protected BaseRepository<E, ID> baseRepository;

    @Override
    public List<E> listarTodos() {
        return baseRepository.findAll();
    }

    @Override
    public Optional<E> buscarPorId(ID id) {
        return baseRepository.findById(id);
    }

    @Override
    public E guardar(E entidad) {
        return baseRepository.save(entidad);
    }

    @Override
    public void eliminar(ID id) {
        baseRepository.deleteById(id);
    }
}
