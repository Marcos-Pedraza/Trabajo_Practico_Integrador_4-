package entidades.servicios;

import entidades.Cliente;
import org.springframework.stereotype.Service;

@Service
public class ClienteService extends BaseServiceImpl<Cliente, Long> {
}
