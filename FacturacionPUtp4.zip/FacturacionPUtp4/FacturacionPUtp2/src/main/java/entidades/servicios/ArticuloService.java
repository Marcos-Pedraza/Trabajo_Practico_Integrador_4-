package entidades.servicios;

import entidades.Articulo;
import org.springframework.stereotype.Service;

@Service
public class ArticuloService extends BaseServiceImpl<Articulo, Long> {
}
