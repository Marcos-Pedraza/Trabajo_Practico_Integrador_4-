package entidades.servicios;

import entidades.DTOs.FacturaReporteDTO;
import entidades.FacturaVenta;
import entidades.repositorios.FacturaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class FacturaService extends BaseServiceImpl<FacturaVenta, Long> {

    private final FacturaRepository facturaRepository;

    @Autowired
    public FacturaService(FacturaRepository facturaRepository) {
        this.facturaRepository = facturaRepository;
    }

    public List<FacturaReporteDTO> buscarFacturas(Date fechaDesde, Date fechaHasta, String estado, Double montoMinimo) {
        return facturaRepository.buscarFacturasConFiltros(fechaDesde, fechaHasta, estado, montoMinimo);
    }
}