package entidades;

import jakarta.persistence.*;
import lombok.*;


@Entity
@Table(name = "contactos")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(callSuper = true)
@ToString
public class Contacto extends EntityId {
    private String email;
    private String telefono;
    private String celular;

}

