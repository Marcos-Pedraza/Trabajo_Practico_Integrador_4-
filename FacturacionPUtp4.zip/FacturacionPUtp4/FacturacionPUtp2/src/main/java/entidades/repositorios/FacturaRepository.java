package entidades.repositorios;

import entidades.DTOs.FacturaReporteDTO;
import entidades.FacturaVenta;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface FacturaRepository extends BaseRepository<FacturaVenta, Long> {

    @Query("SELECT new entidades.DTOs.FacturaReporteDTO(" +
            "f.id, " +
            "f.numero, " +
            "f.fechaEmision, " +
            "c.denominacion, " +
            "c.cuit, " +
            "f.importeTotal, " +
            "f.estado, " +
            "COUNT(d.id)) " +
            "FROM FacturaVenta f " +
            "LEFT JOIN f.cliente c " +
            "LEFT JOIN f.detalles d " +
            "WHERE (:fechaDesde IS NULL OR f.fechaEmision >= :fechaDesde) " +
            "AND (:fechaHasta IS NULL OR f.fechaEmision <= :fechaHasta) " +
            "AND (:estado IS NULL OR f.estado = :estado) " +
            "AND (:montoMinimo IS NULL OR f.importeTotal >= :montoMinimo) " +
            "GROUP BY f.id, f.numero, f.fechaEmision, c.denominacion, c.cuit, f.importeTotal, f.estado")
    List<FacturaReporteDTO> buscarFacturasConFiltros(
            @Param("fechaDesde") Date fechaDesde,
            @Param("fechaHasta") Date fechaHasta,
            @Param("estado") String estado,
            @Param("montoMinimo") Double montoMinimo
    );
}
