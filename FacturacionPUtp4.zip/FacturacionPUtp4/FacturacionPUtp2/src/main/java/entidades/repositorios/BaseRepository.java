package entidades.repositorios;

import entidades.EntityId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

import java.io.Serializable;

@NoRepositoryBean
public interface BaseRepository<E extends EntityId, ID extends Serializable> extends JpaRepository<E, ID> {
}
