package entidades;

import lombok.*;
import jakarta.persistence.*;

@Entity
@Table(name = "factura_venta_detalle")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
// Excluimos la referencia bidireccional a "factura" para prevenir bucles infinitos
@EqualsAndHashCode(callSuper = true, exclude = {"factura"})
@ToString(exclude = {"factura"})
public class FacturaVentaDetalle extends EntityId {

    private int cantidad;
    private double precioUnitario;
    private double subtotal;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "factura_id", nullable = false)
    private FacturaVenta factura;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "articulo_id", nullable = false)
    private Articulo articulo;
}
