package entidades.controladores;

import entidades.DTOs.FacturaReporteDTO;
import entidades.servicios.FacturaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/api/facturas")
public class FacturaRestController {

    private final FacturaService facturaService;

    @Autowired
    public FacturaRestController(FacturaService facturaService) {
        this.facturaService = facturaService;
    }

    @GetMapping
    public ResponseEntity<List<FacturaReporteDTO>> getFacturas(
            @RequestParam(name = "fechaDesde", required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date fechaDesde,

            @RequestParam(name = "fechaHasta", required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date fechaHasta,

            @RequestParam(name = "estado", required = false) String estado,

            @RequestParam(name = "montoMinimo", required = false) Double montoMinimo) {

        List<FacturaReporteDTO> facturas = facturaService.buscarFacturas(fechaDesde, fechaHasta, estado, montoMinimo);
        return ResponseEntity.ok(facturas);
    }
}
