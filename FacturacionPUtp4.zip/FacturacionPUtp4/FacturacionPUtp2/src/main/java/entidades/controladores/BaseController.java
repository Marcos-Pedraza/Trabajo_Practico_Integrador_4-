package entidades.controladores;

import entidades.EntityId;
import entidades.servicios.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.Serializable;
import java.util.List;

public abstract class BaseController<E extends EntityId, ID extends Serializable> {

    @Autowired
    protected BaseService<E, ID> baseService;

    @GetMapping
    public ResponseEntity<List<E>> listarTodos() {
        return ResponseEntity.ok(baseService.listarTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<E> buscarPorId(@PathVariable ID id) {
        return baseService.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<E> crear(@RequestBody E entidad) {
        return ResponseEntity.ok(baseService.guardar(entidad));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable ID id) {
        baseService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
