package entidades.controladores;

import entidades.Articulo;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/articulos")
public class ArticuloRestController extends BaseController<Articulo, Long> {
}
