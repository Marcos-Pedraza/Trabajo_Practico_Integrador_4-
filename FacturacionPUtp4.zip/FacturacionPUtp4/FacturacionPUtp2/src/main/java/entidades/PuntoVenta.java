package entidades;

import lombok.*;
import jakarta.persistence.*;

@Entity
@Table(name = "punto_venta")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(callSuper = true)
@ToString
public class PuntoVenta extends EntityId {

    private int numero;
    private String descripcion;
}

