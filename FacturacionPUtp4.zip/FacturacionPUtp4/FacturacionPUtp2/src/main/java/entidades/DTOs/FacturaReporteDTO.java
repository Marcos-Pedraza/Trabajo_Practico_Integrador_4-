package entidades.DTOs;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class FacturaReporteDTO {

    private Long id;
    private Long numeroFactura;
    private Date fechaEmision;

    private String razonSocialCliente;
    private String cuitCliente;

    private Double totalFactura;
    private String estado;

    private Long cantidadItems;
}